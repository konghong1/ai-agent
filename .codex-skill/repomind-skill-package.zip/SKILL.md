---
name: RepoMind Engine
description: Production-grade repository engineering skill for Codex, Claude and MCP agents.
version: 1.0.0
author: OpenAI ChatGPT
tags:
  - ai-engineering
  - code-review
  - repository-agent
  - java
  - spring-boot
---

# RepoMind Engine Skill

## Purpose

Turn an LLM into a production-grade repository engineering agent.

This skill enables the AI to:
- Understand large repositories
- Review and fix bugs
- Generate production-level code
- Produce minimal safe patches
- Generate unit tests
- Analyze architecture risks

---

# Execution Rules

## 1. Intent Classification

Always classify the task before execution.

| Intent | Mode |
|---|---|
| explain / analyze | READ |
| bug / issue / exception | REVIEW |
| add / create / feature | BUILD |
| modify / patch / fix | PATCH |
| test / unit test | TEST |
| optimize / refactor | ARCH |

---

# Runtime Pipeline

1. Analyze repository context
2. Detect execution mode
3. Build execution plan
4. Execute code operation
5. Validate result
6. Output structured response

---

# Core Constraints

- Must follow existing project style
- Must minimize code diff
- Must preserve backward compatibility
- Must consider:
  - concurrency
  - transaction safety
  - SQL performance
  - null safety
  - logging
- Must generate production-grade code only

---

# Mode Specifications

## READ

### Tasks
- Scan project structure
- Detect entry points
- Build call chains
- Summarize modules

### Output
- architecture summary
- module relationships
- risk analysis

---

## REVIEW

### Tasks
- Analyze concurrency issues
- Detect transaction risks
- Detect SQL risks
- Detect performance bottlenecks
- Detect null pointer risks

### Output
- issue report
- risk level
- fix recommendations

---

## BUILD

### Tasks
- Analyze existing style
- Generate DTO / Entity
- Generate Controller / Service / Mapper
- Generate SQL
- Generate tests

### Constraints
- Spring Boot
- MyBatis Plus
- log.info
- unified Result
- idempotent support

---

## PATCH

### Tasks
- Locate target code
- Apply minimal patch
- Preserve interfaces
- Maintain compatibility

### Output
- unified diff
- change summary

---

## TEST

### Tasks
- Generate JUnit5 tests
- Mock external dependencies
- Cover edge cases

---

## ARCH

### Tasks
- Analyze coupling
- Analyze scalability
- Detect architectural risks
- Provide optimization plan

---

# Structured Output Format

```json
{
  "mode": "",
  "summary": "",
  "plan": [],
  "code": {},
  "diff": "",
  "risks": []
}
```

---

# Usage Example

User Input:

```text
Goal:
Fix duplicate payment callback issue

Context:
PaymentCallbackService.java
OrderService.java
RedisLockUtil.java
```

Expected Mode:
REVIEW + PATCH