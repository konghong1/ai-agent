#!/bin/bash

echo "RepoMind Engine Skill Runtime"

echo "1. Load repository context"
echo "2. Detect intent"
echo "3. Execute pipeline"
echo "4. Return structured JSON"