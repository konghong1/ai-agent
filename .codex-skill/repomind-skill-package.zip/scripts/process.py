def classify_intent(goal: str) -> str:
    goal = goal.lower()

    rules = {
        "REVIEW": ["bug", "issue", "error", "exception"],
        "BUILD": ["add", "create", "feature", "implement"],
        "PATCH": ["fix", "patch", "modify"],
        "READ": ["analyze", "explain", "understand"],
        "TEST": ["test", "mock", "coverage"],
        "ARCH": ["optimize", "refactor", "architecture"]
    }

    for mode, keywords in rules.items():
        if any(word in goal for word in keywords):
            return mode

    return "READ"


if __name__ == "__main__":
    example = "fix payment callback bug"
    print(classify_intent(example))